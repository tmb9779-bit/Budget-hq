# Budget HQ 0.9.45 — Apply transactions to personal debt

Transactions now offers Apply to Personal Debt on eligible posted cash outflows, including imported Venmo history. Choose your debt, principal amount, and scheduled occurrence or extra payment. Cash is not deducted again. Use Already Included if the debt balance already reflects that payment. Older payments before the debt starting balance must use this history-only option. Matching an existing payment preserves its principal and schedule instead of recording it twice.

Pending, transfer, excluded and already-linked records cannot be applied. Venmo payments are never assumed to be debt automatically. View linked payments in Debt; deleting the payment link preserves the transaction and restores its previous category.

Stop the old server, extract this update, and start Budget HQ. Refresh the browser with Ctrl+Shift+R. Existing budget data is stored separately; do not delete or reset it.

# Budget HQ 0.9.44 — Simpler planning and scheduled debt

Removed the Overdue Bills card from Calendar, Forecast Options and Bills Included in Forecast panels from Plan, and Wish Protection controls and automatic buffer-based wish pauses. Existing bill schedules still feed the forecast automatically; individually paused wishes remain paused.

Recurring suggestions disappear when none remain to review. Dismissed recurring suggestions can be restored from Settings → Data & Recovery. Debt account forms exclude cash and include Personal debt separately from Loan. Scheduled payment history now shows upcoming debt payments from the same 60-day schedule as Calendar and Plan, separately from recorded payments.

Goal Savings and financial goal cards now use forecast surplus above the buffer, without requiring a Goals allocation percentage, capped by each paycheck and outstanding targets. Starter Emergency reserve, Travel fund, and Home down payment cards appear automatically; set their targets before they enter your savings plan. Includes the 0.9.43 Home dialog refinements.

Car Repairs is a personal budget record, not bundled sample data. Open Debt → Car Repairs → Delete to remove it locally. If existing activity blocks deletion, preserve those records and review the message before moving or removing history.

Stop the old server, extract this update, and start Budget HQ. Refresh the browser with Ctrl+Shift+R. Existing budget data is stored separately; do not delete or reset it.

# Budget HQ 0.9.43 — Home pop-up refinements

Current Cash Accounts again shows the last seven transactions. Safe to Spend uses its full-size icon without the arrow and shows a running balance after each deduction. Removed the redundant shortfall message. Next Paycheck Plan and forms use tighter spacing; Financial Goals use the same priority dots as Wishes and Needs.

Stop the old server, extract this update, and start Budget HQ. Refresh the browser with Ctrl+Shift+R. Existing budget data is stored separately; do not delete or reset it.

# Budget HQ 0.9.42 — Resolve bank account conflicts

Sync Available Data, then open Resolve Account Conflicts on Home or Bank Connections. For Regular Share, select the correct saved account if offered, or choose A separate account. The selected account is reconciled to its bank balance and included in cash immediately. Sync again to import any newly linked transaction history. Existing history is preserved and no new Plaid connection is created.

Stop the old server before starting this version and refresh the browser with Ctrl+Shift+R.

# Budget HQ 0.9.41 — Fix blank Home on startup

Fixed an undeclared Goal Savings function that stopped the browser module before Home loaded. Added a native module startup regression test. Includes all 0.9.40 features.

Stop the old server, extract this update, and start Budget HQ. Refresh the browser with Ctrl+Shift+R. Existing budget data is stored separately; do not delete or reset it.

# Budget HQ 0.9.40 — Fresh balances and clear Plan deductions

Goal Savings by Paycheck now projects contributions from the 60-day forecast, respects the Goals share, protects the buffer across remaining days, and reserves earlier projected contributions before later ones.

Plan now shows all included bill occurrences, restores the bill list in each paycheck period, and shows starting cash + income − bills = ending cash when inspecting a forecast day. Regression checks cover multiple paychecks, bills, and debt payments on the same day. Schedule warnings also appear in Plan.

Request Fresh Bank Data now requests fresh transactions and fresh balances on existing bank connections. The returned balances flow into My Balance and Safe to Spend through the existing cash calculations, without subtracting pending charges twice. Balance status and errors appear separately from transaction refresh status. Unavailable fresh balance requests fall back to available Plaid data with a visible warning.

Balance and Transactions Refresh are included in Plaid’s free Trial. This update does not change your plan, create bank connections, or enroll you in paid services. Budget HQ cannot verify your billing plan; paid-plan terms apply if you upgrade through Plaid. Ordinary Sync Available Data and scheduled background syncs do not request fresh Balance data.

Stop the old Budget HQ server and start this version. Click Connected, then Request Fresh Bank Data beside Scott. Check Fresh bank balance request for the result.

# Budget HQ 0.9.39 — Request fresh bank transactions

Request Fresh Bank Data calls Plaid Transactions Refresh, then retrieves and imports the latest data. Ordinary Refresh / Sync Available Data does not request that paid add-on. Existing connections are reused. Background syncs continue retrieving available data without on-demand requests. Per-bank status shows fresh-request success or failure separately from ordinary sync success.

Plaid Transactions Refresh is an optional, separately billed add-on requiring access. Capital One credit-card-only connections do not support it and fall back to available data. Balances may still be cached, and pending details depend on bank support. No new connections or paid plan subscriptions are created by this update.

Stop the old server before starting this version. Use Request Fresh Bank Data only when you want the optional Plaid service. Check Scott’s Fresh bank transaction request status afterward.

# Budget HQ 0.9.38 — Clear bank refresh status

Refresh now shows progress and failures on the page. Pending Sync Status separates the latest refresh attempt from the last successful account check. Failed checks preserve existing pending records.

Stop the old Budget HQ server before starting this version, then refresh your bank connection.

# Budget HQ 0.9.37 — Spending account choices

Record Spending now limits Paid From to cash accounts and credit cards. Loans remain available as debts to pay. Added explanations for transfers and historical entries.

# Budget HQ 0.9.36 — Compact Wish priority choices

Add a Wish now uses small priority radio buttons like Need, keeping High, Normal, and Low priorities. Field spacing and expandable sections are tighter. Existing wish priorities are preserved.

# Budget HQ 0.9.35 — Home cash pop-up and realistic paycheck allocations

Home → My Balance / Current Cash Accounts now shows one total and one row per cash-account record. Removed the repeated account breakdown and pending/recent transaction lists from this pop-up. View Transactions opens activity and pending details. Each account row uses the same adjusted cash amount as My Balance, so the rows add up to the displayed total. Edit and Manage Accounts remain available.

This removes duplicate presentation of an account such as Extreme Checking. It does not delete or merge saved accounts, balances or transaction history. Distinct account records with the same name remain distinct.

Next Paycheck Plan assigns $0 (0%) to Goals, Sinking Funds and Wishes when there are no active unfinished targets. Manually paused targets and debt-milestone goals do not receive savings allocations. Extra Debt is $0 if no active debt has a balance. Unused shares go to Flexible Spending; saved allocation percentages remain unchanged. Buffer protection still holds eligible wish allocations when cash is below the buffer.

Stop the server, replace the app folder, restart using the same user/data-home setting, and refresh the browser. All prior fixes and pending diagnostics are retained.

---

# Budget HQ 0.9.34 — keep the forecast in Plan

Removed the added 60-day forecast summary and daily projected-balance section from Calendar. Calendar retains its monthly totals, bill dates and normal day details. Plan retains the 60-day forecast using the same recurring bill and debt schedules.

Monthly bills repeat on their scheduled day throughout the forecast window; paid, skipped and cancelled occurrences are excluded from upcoming cash deductions. Overdue reserves still appear in Plan's daily details when enabled. The calculation uses saved bill amounts, due dates and recurrence settings. If a bill lacks a valid schedule, use Edit Schedule in Schedules Needing Attention.

Stop the server, replace the app folder, restart with the same user/data-home setting and refresh the browser. All earlier fixes, including Scott Credit Union pending diagnostics, are retained.

---

# Budget HQ 0.9.33 — calendar/forecast consistency and pending diagnostics

## Install
Stop the server, replace the app folder with this extracted version, restart under the same user and data-home setting, and refresh the browser. Confirm Settings shows 0.9.33. All prior updates are included.

## Calendar and 60-day forecast
The calendar now receives its budget and forecast from the same server snapshot. A new Same 60-Day Forecast as Plan summary shows the exact forecast dates, starting cash after saved money, expected income, bills/debt and ending balance. Select a calendar day to see the corresponding forecast income, outflows and projected balance. Overdue amounts reserved today are itemized in both the calendar and forecast day details, while original bill dates remain visible.

The calendar's former PREDICTED monthly card is now MONTHLY SCHEDULED. It includes scheduled amounts already paid during the selected month. This monthly historical comparison is intentionally distinct from a forward-looking 60-day cash forecast of remaining payments. The new captions explain the difference.

## Scott Credit Union pending charges
Transactions → Pending Bank Activity → Pending Sync Status now reports counts separately for each bank: received, imported and withheld, plus withholding reasons and the connection check timestamp. Click Refresh Bank Connection there to populate the diagnostics. No bank credentials or raw bank payloads are displayed.

A received count of zero means no pending records were supplied in the cached transaction data available to that sync; it does not prove the bank lacks support. A failed sync is explicitly labeled rather than reported as zero. Withheld records identify account mapping, discarded records, missing/unsupported currency or invalid fields. Individual pending charges may not be available even when the available balance reflects holds.

Scott Credit Union's live pending-transaction support has not been verified. To identify the remaining issue, send the Scott Credit Union Pending Sync Status counts and timestamp after refresh. No account number or transaction amounts are needed.

## Validation
Automated checks cover all-day equality of calendar/forecast income and outflows, overdue reserves, partial debt payments, UI breakdowns, and pending diagnostic counts for success, zero records, withholding and failure. All 110 tests in the affected UI and calendar-consistency suites passed after the final changes. The broader suite also verified the remaining ledger, HTTP, bank-import and scheduling checks. No live bank connection or real-browser visual verification was available.

---

# Budget HQ 0.9.32 — pending activity, paydays, calendar audit

## Install
Stop the Budget HQ server, replace the app folder with this extracted version, restart START_BUDGET_HQ.cmd using the same Windows user and data-home setting, and refresh the browser. Settings should display version 0.9.32. Refresh the bank connection to retrieve pending entries previously withheld for a future posting date. All earlier updates are included.

## Confirmed fixes
- Transactions now has a Pending Bank Activity panel covering active cash and credit accounts, separate from recorded spending. Card purchases do not reduce checking cash.
- Pending transactions with bank-supplied future posting dates are retained. Posted future transactions are still withheld. Pending entries remain unbooked and available balances are not reduced twice.
- Income occurrences are sorted by date across all income sources, so Next Payday uses the closest eligible occurrence, not the first source entered. Paid occurrences are excluded.
- Idle refresh updates the budget on a new day even when the saved revision is unchanged; returning to the app also checks for updates. Open forms and Design Mode defer refresh.
- Opening Calendar without a specific month uses the current budget month. Explicitly selected month routes still work.
- Calendar estimates now include paid scheduled amounts without deleting payment history from the balance calculation. Calendar requests use one budget snapshot.
- Emergency-fund essential-cost calculations now include recurring bills categorized as Car, consistent with the existing transportation description.

## Recurring bills and estimates
Active, valid recurring bills and debt schedules generate calendar events and forecast expenses. Positive debt balances require a payment amount, due date and supported frequency. Existing debt inputs are linked entries, not duplicate bills.

Calendar now shows Schedules Needing Attention for missing/invalid dates, missing amounts, unsupported recurrence values and expired one-time dates. Edit Schedule opens the relevant bill or debt. Complete the actual details there; the app does not invent due dates. Previously skipped/cancelled occurrences remain excluded; paid occurrences are excluded from outstanding bills but included in predicted scheduled totals.

## Verification and limits
311 automated tests passed, including HTTP, ledger, categorization, recurring schedules, pending transitions and UI rendering contracts. Tests cover pending activity on cash and cards, future pending dates, multiple employers in reverse date order, date rollover without a revision change, recurring bill/debt inclusion in forecast totals, and paid debt estimates without changing ledger balances.

The local app package contains no live user budget or bank history. The reported missing-bill issue cannot be attributed to one specific saved record without that data. Tests verify valid schedules; the new panel identifies incomplete schedules in the running app. If an apparently valid bill is still absent, share its Edit Schedule fields and the selected calendar month, with personal details removed.

Pending items can only be displayed when the bank supplies them. Bank available balance may contain holds for which no individual pending transaction was returned. The panel says this explicitly; it never invents transaction details. A real browser visual review and live bank synchronization were not performed.

---

# Budget HQ 0.9.31 — debt inputs in recurring charges

Calendar → Recurring & Planned Bills now includes active debts with a positive balance, linked directly to their account's payment amount, due date and frequency. Debt schedule edits and bank-provided minimum payment updates are reflected automatically. No separate bill copy is created, so existing calendar and Safe to Spend calculations continue to count each debt schedule once.

Use Edit Debt Schedule on a linked row to change the payment amount, date or recurrence. Missing payment amounts/dates show setup prompts. Fully paid or inactive debts are hidden. A debt set to One-time appears under One-time Bills. The entered payment is the scheduled/minimum payment, not the entire debt balance. This schedules budget entries only; it does not send money to lenders.

Stop the server, replace the app folder with this version, restart under the same user/data-home setting and refresh the browser. Existing debt inputs appear automatically. Includes all prior updates.

---

# Budget HQ 0.9.30 — My Balance includes pending charges

My Balance now uses bank available balances for checking/savings when provided, capped at posted cash so extra available credit or pending deposits do not inflate the total. Pending charges are not subtracted again from a bank available balance. When available balance is missing, the app estimates posted cash minus reported pending outflows. Estimates depend on the bank's pending data and balance conventions.

Tap My Balance for posted cash, the pending/hold adjustment, each account's calculation method, and pending charges. Safe to Spend and cash forecasts use the same adjusted cash amount. Credit-card purchases remain on the card and do not reduce checking cash until a payment occurs. Ledger balances and reconciliation remain posted, and pending transactions do not become booked spending.

Install: stop the server, replace the application folder, restart under the same user/data-home setting, then refresh the browser and bank connection. Bank data may be cached; pending amounts can change. All previous updates are included.

---

# Budget HQ 0.9.29 — Need categories, icons, and suggested financial goals

Needs now have a Bill Category dropdown in the Plan a Need / scheduling dialog. Choose a category or leave Automatic selected for the existing description-based rules. Your choice is saved with the Need and carried into its one-time bill when scheduled. Existing scheduled bills can be recategorized with Edit Expense.

Nine transaction categories now have dedicated icons: Pets (paw), Personal care (mirror/comb), Services (wrench), Education (graduation cap), Insurance (shield/check), Bank fees (bank/minus), Government & taxes (government building/document), Donations (hand/heart), and Home improvement (house/hammer). Icons use the app's existing SVG style and category color palette.

New Financial Goals offer ten starting ideas: emergency fund, credit card payoff, loan payoff, car repair fund, vet emergency fund, education, travel, moving, home down payment, and annual bills reserve. Select an idea, then choose your own amount, date or debt account. Nothing is created until you save. Existing goal edits keep their current values.

Stop the server, replace the app folder with this extracted version, restart under the same user/data-home setting, and refresh your browser. All previous fixes are included.

---

# Budget HQ 0.9.28 — restore schedule review

Fixes the missing Planning Preferences control after the Settings redesign. The Review Planning button in the setup banner now opens the correct dialog directly. The same control is available at Settings → Privacy & Preferences → Planning Preferences → Review Planning.

After checking your recurring bills, debt due dates and expected paycheck schedules, tick “I Have Checked My Recurring Bills, Debt Due Dates, and Expected Paycheck Schedules” and Save. This marks the schedule reviewed, not a paycheck received. Safe to Spend appears when cash accounts exist, balances are confirmed, and required debt due dates are complete. The app does not automatically confirm these for you.

Install: stop the server, replace the app folder with this extracted version, and restart START_BUDGET_HQ.cmd using the same user/data-home setting. Refresh the browser. All prior income, categorization and credit utilization updates are included.

---

# Budget HQ 0.9.27 — income suggestions with gaps

Fixes income patterns such as August 27, September 3, and September 17: a seven-day gap followed by a fourteen-day gap can now produce a tentative weekly suggestion. Regular biweekly history remains biweekly. Suggestions with gaps explicitly ask you to confirm frequency and next payday. No missing deposits are created and no future income schedule is saved without review.

Stop the server, replace the app folder with this extracted version, and restart START_BUDGET_HQ.cmd under the same user/data-home setting. Refresh the browser, then open Settings → Income → Suggested Paychecks & Income. If your transactions are already Income, you do not need to recategorize them. Review Alamo and confirm your actual pay frequency, expected amount and next payday.

Includes previous categorization and credit utilization fixes. Tested with the reported dates and simulated transactions; the user's complete bank history was not available.

---

# Budget HQ 0.9.26 — Alamo Drafthouse income

Incoming Alamo Drafthouse deposits now count as income, including Alamo Draft House spelling and bank descriptions with payroll suffixes. Explicit refunds, reversals, reimbursements and peer-to-peer transfers are excluded from this employer rule. Outgoing purchases retain spending categories.

Stop the server, replace the app folder with this extracted version and restart under the same user/data-home setting. Open Transactions → Auto-categorize Other to repair old automatic Alamo categories too. Manual category choices and linked records remain protected. Then open Settings → Income → Suggested Paychecks & Income. Three regularly spaced deposits in one cash account are required before a suggestion appears; review it to set the next payday and expected amount. If history is insufficient, add the income schedule manually. Existing Alamo income schedules suppress duplicate suggestions.

Includes credit utilization bars and prior category fixes. No live bank records were available for verification; tests use simulated deposits. If a deposit description omits Alamo Drafthouse entirely, provide its description (without account details) so its payroll alias can be added accurately.

---

# Budget HQ 0.9.25 — credit utilization bars

Credit cards show current balance / credit limit again. The bar changes from green (below 10%) to yellow (10–29.9%), orange (30–49.9%), and red (50%+). These are display bands. Over-limit values retain the actual percentage, with the bar capped at full width. Missing credit limits show an instruction instead of a misleading percentage. Loans still show payoff progress.

Stop the server, replace the application folder with this extracted version, and restart START_BUDGET_HQ.cmd under the same user and data-home setting. Refresh the browser. Includes the 0.9.24 categorization fixes.

---

# Budget HQ 0.9.24 — transaction categorization fix

## Install
1. Stop the running Budget HQ server.
2. Extract this ZIP and use its budget-hq-desktop folder in place of the previous app folder.
3. Start with START_BUDGET_HQ.cmd, using the same Windows user and any existing BUDGET_HQ_DATA_HOME setting. Keep the same browser address for your saved design.
4. Open Transactions and click Auto-categorize Other.

Your budget is stored separately from the application folder. This update does not reset your budget or require a new bank connection.

## What changed
- Adds Pets, Personal care, Services, Education, Insurance, Bank fees, Government & taxes, Donations, and Home improvement.
- Uses detailed bank categories plus merchant/description fallback rules when bank categories are missing or unrecognized.
- Retains bank category metadata for later categorization.
- Auto-categorize Other applies saved suggestions and description rules to existing uncategorized transactions. It also turns off the optional category-review setting so future bank imports receive categories automatically.
- Preserves manual category choices, linked payments/transfers, adjustments and excluded transactions.
- Fixes inconsistent category-review behavior on repeat bank refreshes.
- Does not treat every deposit as income: unidentified credits and ambiguous refunds can remain Other.

Previously imported records did not retain bank category metadata. Refresh the bank connection to retrieve available metadata, then run Auto-categorize Other again if needed. Unknown merchants may still require a manual category. Merchant rules describe likely purchase types, not item-level receipt contents.

Validation: 290 existing tests and 3 new categorization regression tests passed with sample/mocked data. Live bank data and visual browser rendering were not tested.

---

# Budget HQ 0.9.23 — bank activity matching

1. Stop the old server with Ctrl+C.
2. Extract this ZIP into a new folder. Do not merge it with the old folder.
3. Run START_BUDGET_HQ.cmd or npm start.
4. Open http://localhost:4173 and use your existing app password.
5. Press Ctrl+Shift+R once.

Uses the clean budget introduced in 0.9.18 (existing entries are preserved). On its first launch it contains no accounts, bills, income, needs, wishes, goals, payments, transactions or bank connections. The cash buffer starts at zero until you set it in Plan. No spreadsheet snapshot is loaded. The bundled old financial snapshot has been removed.

Your approved design and sign-in are retained. Browser-saved design edits still take precedence. Older budget folders on your computer are not erased, but this version does not load them. New entries in this clean budget persist across restarts.

The popup flash fix is included. Reset Design restores the included approved design.

Live bank connection: Settings → Accounts & Connections → Plaid Connection. Enter Production credentials only in the local app. Connecting or refreshing now creates and updates supported USD accounts using Plaid current balances. Transactions now import as history without affecting snapshot balances again. Supported APRs, minimum payments and due dates populate existing debt accounts. Google OAuth credentials are not Plaid credentials.

## Suggested Recurring Bills
Open Calendar → Suggested Recurring Bills after importing transaction history. Transactions also links there when suggestions are available.

- At least three regularly spaced posted charges for the same merchant and account are required. Matching is conservative; changing merchant descriptions may need a manually added bill.
- Review shows the supporting charges. Confirm or edit the name, latest-charge estimate, frequency and next due date, then Save. Amounts can vary; provider dates should be checked.
- Saving creates a future recurring bill, never another historical charge or cash deduction. Existing same-name recurring bills and scheduled debts are excluded; accepted suggestion identities prevent repeated acceptance.
- Use Not a Recurring Bill to dismiss a pattern. Dismissed Suggestions offers Restore.
- Pending charges, transfers, debt payments, corrections, suspected duplicates and unaccepted imported history are excluded. Older inactive patterns are withheld. This is not a guarantee that every subscription is found.
- The new Review Suggested Bill pop-up is included in Edit Layout.

This update preserves the existing budget, bank connections and design. No reset or new Plaid setup is required. It uses the history already available in the app; limited history may produce no suggestions. All 269 automated tests passed using sample/mocked data. Live bank behavior and visual browser rendering were not verified here.

## Suggested Paychecks & Income
Open Settings → Income → Suggested Paychecks & Income. Transactions links there when suggestions are available. The new Review Suggested Income pop-up is also available in Edit Layout.

- Uses at least three regularly spaced posted deposits categorized as Income, from the same source and cash account. Categorize genuine income in Transactions first. Different descriptions, limited history, irregular pay and unsupported schedules may require manual entry.
- Review supporting deposits, then confirm employer/source, expected take-home pay, frequency and next payday. The suggested amount is the median of matching deposits; variable pay shows its range. Bank posting dates can differ from scheduled paydays, especially around holidays.
- Saving adds one forecast schedule, not cash or duplicate historical transactions. Existing source names and accepted source identities prevent repeated suggestions. Verify the schedule before relying on forecast income.
- Known transfers, refunds, corrections, pending deposits and suspected duplicates are excluded. Classification is imperfect: confirm that a suggestion represents genuine income rather than a transfer or reimbursement.
- Not Regular Income dismisses a suggestion; Dismissed Income Suggestions lets you restore it. Bill and income dismissals are separate.

The update preserves the current budget, bank connection and supplied design. All 276 automated tests passed with sample/mocked data. Live bank behavior and visual browser rendering remain unverified here.

## Bank Activity Matches
Open Transactions → Bank Activity Matches after refreshing Plaid.

- Paycheck: review imported deposit versus expected pay, then confirm. Advances the source schedule and records expected versus actual without adding cash again.
- Bill: review imported charge versus scheduled bill. Completes only that occurrence; never inserts another expense.
- Transfer: review both accounts and confirm equal opposite entries. Categorizes both as Transfer, excluding them from income/spending totals.
- Card/loan payment: links the cash outflow and debt-account inflow. Counts the cash-side payment once without reducing principal again. Optionally choose a matching scheduled debt payment to complete; otherwise the schedule remains unchanged. This does not create an additional manually recorded payment.
- Ambiguous candidates require your selection. Amount/date proximity is not proof. Unaccepted imported history still uses the existing Imported History review.
- Confirmed Matches offers Unlink. Unlink later paycheck matches first if undoing earlier paychecks. Dismissed matches can be restored.
- If a bank removes or modifies a matched record, it is flagged for review; the schedule is not silently rewritten. Unlink and review the affected schedule. Removed bank records are excluded from reports.
- Review pop-ups are registered in Edit Layout, individually scoped by match type.

Settings → Accounts & Connections now shows each bank's app check time, bank transaction update time, available balance timestamps, product errors and consent notices. Reconnect remains next to the affected bank. Unknown timestamps are not presented as fresh.

Your 6 a.m. daily refresh and top-right manual refresh continue to work while the server is running. Optional bank-update notifications are prepared but OFF until hosting is configured; see PLAID_NOTIFICATIONS.md. No public hosting or bank setup was changed remotely.

Validation: the full existing suite plus targeted matching, webhook, freshness and UI checks passed using mocked/sample data. No live bank writes or calls were used. Real bank data and browser rendering still require verification on your computer.
