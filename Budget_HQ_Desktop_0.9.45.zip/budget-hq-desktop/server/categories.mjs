import {isAlamoIncome} from '../income-source.js';
// Shared classification for new bank records and existing uncategorized history.
export const CATEGORIES=['Income','Food','Shopping','Housing','Utilities','Transportation','Medical','Vet Bills','Pets','Entertainment','Travel','Personal care','Services','Education','Insurance','Bank fees','Government & taxes','Donations','Home improvement','Debt payment','Transfer','Other'];
const primary={INCOME:'Income',FOOD_AND_DRINK:'Food',GENERAL_MERCHANDISE:'Shopping',RENT_AND_UTILITIES:'Utilities',TRANSPORTATION:'Transportation',MEDICAL:'Medical',ENTERTAINMENT:'Entertainment',TRAVEL:'Travel',PERSONAL_CARE:'Personal care',GENERAL_SERVICES:'Services',BANK_FEES:'Bank fees',GOVERNMENT_AND_NON_PROFIT:'Government & taxes',HOME_IMPROVEMENT:'Home improvement'};
const rules=[
 [/\b(payroll|paycheck|salary|direct dep(?:osit)?|dir dep|ssa treas|social security)\b/,'Income'],
 [/\b(credit card payment|loan payment|autopay payment)\b/,'Debt payment'],
 [/\b(zelle|venmo|cash app|transfer)\b/,'Transfer'],
 [/\b(veterinary|veterinarian|animal hospital|vet clinic|banfield)\b/,'Vet Bills'],
 [/\b(petco|petsmart|chewy|pet supplies)\b/,'Pets'],
 [/\b(kroger|aldi|trader joe|whole foods|safeway|publix|h e b|heb|grocery|groceries|restaurant|cafe|coffee|starbucks|mcdonald|chipotle|taco bell|doordash|uber eats|grubhub|pizza)\b/,'Food'],
 [/\b(shell|chevron|exxon|texaco|bp|gas station|uber|lyft|parking|toll)\b/,'Transportation'],
 [/\b(netflix|spotify|hulu|cinema|alamo drafthouse|movie|steamgames)\b/,'Entertainment'],
 [/\b(walmart|wal mart|target|amazon|amzn|ebay|etsy|goodwill|costco)\b/,'Shopping'],
 [/\b(cvs|walgreens|pharmacy|hospital|dental|dentist|medical)\b/,'Medical'],
 [/\b(rent|mortgage)\b/,'Housing'],
 [/\b(electric|water bill|internet|comcast|spectrum|verizon|at t|t mobile)\b/,'Utilities'],
 [/\b(insurance|geico|progressive|state farm)\b/,'Insurance'],
 [/\b(tuition|student tuition)\b/,'Education'],
 [/\b(overdraft|maintenance fee|atm fee|late fee)\b/,'Bank fees'],
 [/\b(hotel|airbnb|airlines|airways)\b/,'Travel']
];
export function classifyTransaction(t){
 if(isAlamoIncome(t))return 'Income';
 const pfc=t.personal_finance_category||t.bankCategory||{};
 const p=String(pfc.primary||'').toUpperCase(),d=String(pfc.detailed||'').toUpperCase();
 const inflow=t.direction?t.direction==='Inflow':t.amount<0;
 if(p==='LOAN_PAYMENTS')return 'Debt payment';
 if(p.startsWith('TRANSFER'))return /CREDIT_CARD_PAYMENT/.test(d)?'Debt payment':'Transfer';
 if(/VETERINARY/.test(d))return 'Vet Bills';
 if(/PET_SUPPLIES/.test(d))return 'Pets';
 if(/EDUCATION/.test(d))return 'Education';
 if(/INSURANCE/.test(d))return 'Insurance';
 if(/DONATION/.test(d))return 'Donations';
 if(p==='RENT_AND_UTILITIES'&&/RENT/.test(d))return 'Housing';
 if(primary[p]&&(p!=='INCOME'||inflow))return primary[p];
 const legacy=Array.isArray(t.category)?t.category.join(' '):'';
 const name=[t.merchant_name,t.name,t.original_description,legacy].filter(Boolean).join(' ').toLowerCase().replace(/[^a-z0-9]+/g,' ');
 // Refunds and unidentified credits must not become paycheck income.
 if(inflow&&/\b(refund|reversal|cashback|cash back)\b/.test(name))return 'Other';
 for(const [pattern,category] of rules)if(pattern.test(name)&&(category!=='Income'||inflow))return category;
 if(/\b(food|grocery|restaurants)\b/.test(legacy.toLowerCase()))return 'Food';
 return 'Other';
}
export function categorizeOther(book){
 let updated=0;
 for(const t of book.transactions){
  if(t.categoryConfirmed||t.adjustment||t.paymentId||t.bankMatchId||t.toAccountId||t.excluded||t.bankRemoved||(!isAlamoIncome(t)&&!['Other','',undefined,null].includes(t.category)))continue;
  const category=isAlamoIncome(t)?'Income':CATEGORIES.includes(t.suggestedCategory)&&t.suggestedCategory!=='Other'?t.suggestedCategory:classifyTransaction(t);
  if(category==='Other'||category===t.category)continue;
  t.category=category;delete t.suggestedCategory;updated++;
 }
 return updated;
}
