import {homedir} from 'node:os';
import {join} from 'node:path';
// Reuses only the existing local owner password. No Google/Plaid credentials are read.
export const configDir=join(process.env.BUDGET_HQ_DATA_HOME||process.env.LOCALAPPDATA||join(homedir(),'.config'),'BudgetHQ');
export const dataDir=join(configDir,'independent');
