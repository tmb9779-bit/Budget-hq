import {scryptSync,randomBytes,timingSafeEqual} from 'node:crypto';import {readFile} from 'node:fs/promises';import {join} from 'node:path';import {configDir} from './config.mjs';
export const ownerPath=join(configDir,'owner.json');
export const hashPassword=(password,salt)=>scryptSync(password,salt,64).toString('hex');
export async function jsonBody(req,limit=20000){let data='';for await(const c of req){data+=c;if(Buffer.byteLength(data)>limit)throw Error('Request too large.');}return JSON.parse(data||'{}');}
export function createOwnerGate({load=()=>readFile(ownerPath,'utf8').then(JSON.parse),now=Date.now,originAllowed=req=>!req.headers.origin||req.headers.origin==='http://localhost:4173'}={}){
 const sessions=new Map();let attempts=[];
 return async(req,res,url)=>{
  const send=(status,data)=>{res.writeHead(status,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify(data));};
  const key=(req.headers.cookie||'').split(';').map(x=>x.trim()).find(x=>x.startsWith('budget_owner='))?.slice(13);
  for(const [k,v]of sessions)if(v<now())sessions.delete(k);
  if(url.pathname.startsWith('/api/owner/')){
   if(req.headers['x-budget-hq']!=='1'||!originAllowed(req)||req.headers['sec-fetch-site']==='cross-site'){send(403,{error:'Open Budget HQ directly.'});return false;}
   if(url.pathname==='/api/owner/status'&&req.method==='GET'){let configured=true;try{await load();}catch{configured=false;}send(200,{configured,signedIn:sessions.has(key)});return false;}
   if(url.pathname==='/api/owner/login'&&req.method==='POST'){
    attempts=attempts.filter(t=>t>now()-15*60000);if(attempts.length>=5){send(429,{error:'Too many attempts. Try again in 15 minutes.'});return false;}attempts.push(now());
    try{const {password}=await jsonBody(req,2000),config=await load();if(typeof password!=='string'||password.length>256)throw Error();const entered=Buffer.from(hashPassword(password,config.salt),'hex'),saved=Buffer.from(config.hash,'hex');if(saved.length!==entered.length||!timingSafeEqual(saved,entered))throw Error();const token=randomBytes(32).toString('base64url');sessions.delete(key);sessions.set(token,now()+8*3600000);attempts=[];res.setHeader('Set-Cookie',`budget_owner=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=28800`);send(200,{ok:true});}catch{send(401,{error:'Sign-in failed. Check your password or run npm run setup-owner first.'});}return false;
   }
   if(url.pathname==='/api/owner/logout'&&req.method==='POST'){sessions.delete(key);res.setHeader('Set-Cookie','budget_owner=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0');send(200,{ok:true});return false;}
   send(405,{error:'Unsupported action.'});return false;
  }
  if(sessions.has(key))return true;
  if(['/login','/login.js','/styles.css','/mobile.css','/palette.css','/public/app-icon.svg'].includes(url.pathname))return true;
  if(url.pathname.startsWith('/api/'))send(401,{error:'Sign in to Budget HQ first.'});else{res.writeHead(303,{Location:'/login','Cache-Control':'no-store'});res.end();}return false;
 };
}
