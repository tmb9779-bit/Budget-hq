import {createHash,createPublicKey,verify,timingSafeEqual} from 'node:crypto';
// Dedicated receiver: expose only this port/path through HTTPS, never the app port.
export function webhookURL(value){if(!value)return '';const u=new URL(value);if(u.protocol!=='https:'||u.username||u.password||u.search||u.hash||u.pathname!=='/plaid/webhook')throw Error('BUDGET_HQ_PLAID_WEBHOOK_URL must be an HTTPS URL ending in /plaid/webhook.');return u.href;}
export class PlaidWebhooks{
 constructor({store,getKey,refresh,knownItem,now=Date.now}){Object.assign(this,{store,getKey,refresh,knownItem,now});this.tail=Promise.resolve();this.keys=new Map();}
 serial(fn){const work=this.tail.then(fn);this.tail=work.catch(()=>{});return work;}
 async accept(raw,token){if(!this.windowAt||this.now()-this.windowAt>=60000){this.windowAt=this.now();this.windowCount=0;}if(++this.windowCount>60)throw Error('Too many webhook requests. Retry later.');return this.serial(async()=>{
  if(!Buffer.isBuffer(raw)||raw.length>65536||typeof token!=='string'||token.length>8192)throw Error('Invalid webhook.');
  const parts=token.split('.');if(parts.length!==3)throw Error('Invalid signature.');const header=JSON.parse(Buffer.from(parts[0],'base64url')),claims=JSON.parse(Buffer.from(parts[1],'base64url'));
  if(header.alg!=='ES256'||typeof header.kid!=='string'||header.kid.length>200||!Number.isFinite(claims.iat)||claims.iat*1000<this.now()-300000||claims.iat*1000>this.now()+30000)throw Error('Invalid signature or expired webhook.');
  let key=this.keys.get(header.kid);if(!key){key=await this.getKey(header.kid);if(this.keys.size>=64)this.keys.clear();this.keys.set(header.kid,key);}
  if(!key||key.kid!==header.kid||key.alg!=='ES256'||key.crv!=='P-256'||key.kty!=='EC'||key.expired_at!=null)throw Error('Invalid verification key.');
  if(!verify('sha256',Buffer.from(parts[0]+'.'+parts[1]),{key:createPublicKey({key,format:'jwk'}),dsaEncoding:'ieee-p1363'},Buffer.from(parts[2],'base64url')))throw Error('Invalid signature.');
  const hash=createHash('sha256').update(raw).digest(),claimed=Buffer.from(String(claims.request_body_sha256||''),'hex');if(claimed.length!==32||!timingSafeEqual(hash,claimed))throw Error('Invalid body.');
  const event=JSON.parse(raw),supported=event.webhook_type==='TRANSACTIONS'&&['SYNC_UPDATES_AVAILABLE','INITIAL_UPDATE','HISTORICAL_UPDATE','DEFAULT_UPDATE','TRANSACTIONS_REMOVED'].includes(event.webhook_code)||event.webhook_type==='ITEM'&&['ERROR','LOGIN_REPAIRED','PENDING_EXPIRATION','PENDING_DISCONNECT','NEW_ACCOUNTS_AVAILABLE'].includes(event.webhook_code)||event.webhook_type==='LIABILITIES';
  if(!supported||!await this.knownItem(event.item_id))return {ignored:true};
  const queue=await this.store.get('webhook-queue',[]);let job=queue.find(j=>j.id===event.item_id);if(!job){job={id:event.item_id,attempts:0,next:0};queue.push(job);}job.event=event.webhook_code;job.receivedAt=new Date(this.now()).toISOString();await this.store.put('webhook-queue',queue);return {queued:true};
 });}
 async tick(){return this.serial(async()=>{const queue=await this.store.get('webhook-queue',[]);for(const job of queue.filter(j=>j.next<=this.now()))try{await this.refresh(job.id,job.event);queue.splice(queue.indexOf(job),1);}catch{job.attempts++;job.next=this.now()+Math.min(3600000,30000*2**Math.min(job.attempts,7));job.error='Bank update failed; retry scheduled.';}await this.store.put('webhook-queue',queue);});}
}
