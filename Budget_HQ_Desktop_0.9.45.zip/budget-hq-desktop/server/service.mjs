import {applyPlaidAccounts,resolvePlaidAccountConflict} from './plaid-accounts.mjs';
import {normalizeRecovery} from './recycle.mjs';
import {analyzeBudget,monthlyReport} from '../analysis.js';
import {randomUUID} from 'node:crypto';
import {change,summary,today} from './model.mjs';
export class BudgetService{
 constructor(store,seed){this.store=store;this.seed=seed;this.tail=Promise.resolve();this.previews=new Map();}
 async init(){this.envelope=await this.store.get('budget');if(!this.envelope){const book=await this.seed();this.envelope={book,history:[]};await this.store.put('budget',this.envelope);}await this.daily();return this;}
 async daily(){return this.serial(async()=>{await this.expireRecovery();await this.safeCaptureReview();const name='backup-'+today();if(!(await this.store.get(name)))await this.store.put(name,{book:this.envelope.book,createdAt:new Date().toISOString()});});}
 async expireRecovery(asOf=today()){
  const book=normalizeRecovery(this.envelope.book,asOf),history=this.envelope.history.map(h=>({...h,before:normalizeRecovery(h.before,asOf)}));
  if(JSON.stringify(book)===JSON.stringify(this.envelope.book)&&JSON.stringify(history)===JSON.stringify(this.envelope.history))return;
  book.revision=randomUUID();const envelope={book,history};await this.store.put('budget',envelope);this.envelope=envelope;
 }
 async safeCaptureReview(){try{await this.captureReview();this.snapshotError=null;}catch(e){this.snapshotError="Snapshot could not be refreshed. Budget changes are saved; check local storage.";}}
 async captureReview(){const b=this.envelope.book,d=summary(b),month=d.asOf.slice(0,7),name='monthly-'+month,previous=await this.store.get(name),point={date:d.asOf,cash:d.cash.balance,debt:d.accounts.filter(a=>a.kind!=='cash').reduce((n,a)=>n+a.balance,0),reserved:d.protectedSavings,ready:d.ready};await this.store.put(name,{month,first:previous?.first||point,last:point,report:monthlyReport(b,d,month)});this.monthlySnapshots=await Promise.all((await this.store.list('monthly-')).sort().reverse().map(n=>this.store.get(n)));const wins=await this.store.get('milestones',[]),add=(id,title)=>{if(!wins.some(w=>w.id===id))wins.push({id,title,date:d.asOf});};if(d.ready&&d.cash.minimumCash>=d.cash.bufferTarget)add('buffer','Protected buffer covered through the forecast');for(const a of d.accounts.filter(a=>a.kind!=='cash'&&a.openingBalance>0&&a.balance<=0))add('debt:'+a.id,a.name+' paid off');for(const g of [...b.wishes,...b.goals,...b.sinking])for(const percent of [25,50,75,100])if(g.cost>0&&g.saved/g.cost*100>=percent)add('target:'+g.id+':'+percent,g.name+' reached '+percent+'%');await this.store.put('milestones',wins);this.milestones=wins;}
 read(){const base=summary(this.envelope.book);return {book:this.envelope.book,summary:{...base,analysis:analyzeBudget(this.envelope.book,base),snapshotError:this.snapshotError||null,mailStatus:this.mailStatus||null,monthlySnapshots:this.monthlySnapshots||[],milestones:this.milestones||[],needForecast:summary(this.envelope.book,today(),180).plan.forecast},undoId:this.envelope.history[0]?.id||null};}
 serial(fn){const next=this.tail.then(fn);this.tail=next.catch(()=>{});return next;}
 async write({revision,operationId,action,data={}}){return this.serial(async()=>{
  const {book,history}=this.envelope;
  if(typeof operationId!=='string'||operationId.length>100||!operationId)throw Error('Missing operation identity.');
  if(book.receipts.includes(operationId))return {...this.read(),repeated:true};
  if(revision!==book.revision)throw Error('Your budget changed in another tab. Reload before saving.');
  const next=action==='resolvePlaidAccount'?resolvePlaidAccountConflict(book,data):change(book,action,data);next.revision=randomUUID();next.updatedAt=new Date().toISOString();next.receipts=[...book.receipts,operationId].slice(-1000);
  const envelope={book:next,history:[{id:randomUUID(),action,date:next.updatedAt,before:book},...history].slice(0,40)};
  await this.store.put('budget',envelope);this.envelope=envelope;await this.safeCaptureReview();return this.read();
 });}
 async syncPlaidAccounts(items){return this.serial(async()=>{const before=this.envelope.book,result=applyPlaidAccounts(before,items);if(JSON.stringify(result.book)!==JSON.stringify(before)){result.book.revision=randomUUID();result.book.updatedAt=new Date().toISOString();const envelope={book:result.book,history:[{id:randomUUID(),action:'Plaid account balances',date:result.book.updatedAt,before},...this.envelope.history].slice(0,40)};await this.store.put('budget',envelope);this.envelope=envelope;await this.safeCaptureReview();}return {added:result.added,updated:result.updated,imported:result.imported,notes:result.notes};});}
 history(){return this.envelope.history.map(({id,action,date})=>({id,action,date}));}
 async backup(){return this.serial(async()=>{const name='backup-'+Date.now()+'-'+randomUUID().slice(0,8);await this.store.put(name,{book:this.envelope.book,createdAt:new Date().toISOString()});return {id:name};});}
 async backups(){return (await this.store.list('backup-')).sort().reverse();}
 async preview({kind,id}){
  let target,label;
  if(kind==='undo'){const h=this.envelope.history[0];if(!h||h.id!==id)throw Error('Only the latest change can be undone. Reload history.');if(h.date.slice(0,10)<=new Date(Date.now()-30*86400000).toISOString().slice(0,10))throw Error('This undo has expired.');target=normalizeRecovery(h.before,today());label='Undo '+h.action;}
  else if(kind==='backup'){const saved=await this.store.get(id);if(!id.startsWith('backup-')||!saved?.book)throw Error('Backup not found.');target=normalizeRecovery(saved.book,today());label='Restore '+id;}
  else throw Error('Invalid recovery option.');
  const token=randomUUID();this.previews.set(token,{target,revision:this.envelope.book.revision,label,expires:Date.now()+300000});
  return {token,label,accounts:target.accounts.length,transactions:target.transactions.length,payments:target.payments.length,savedAt:target.updatedAt||'Initial migration'};
 }
 async restore({token}){return this.serial(async()=>{
  const p=this.previews.get(token);if(!p||p.expires<Date.now())throw Error('Preview expired. Preview the recovery again.');if(p.revision!==this.envelope.book.revision)throw Error('Budget changed since preview. Preview again before restoring.');
  await this.store.put('backup-before-restore-'+Date.now(),{book:this.envelope.book,createdAt:new Date().toISOString()});
  const next=normalizeRecovery(p.target,today());next.revision=randomUUID();next.updatedAt=new Date().toISOString();next.receipts=[...new Set([...this.envelope.book.receipts,...next.receipts])].slice(-1000);
  const envelope={book:next,history:[{id:randomUUID(),action:p.label,date:next.updatedAt,before:this.envelope.book},...this.envelope.history].slice(0,40)};
  await this.store.put('budget',envelope);this.envelope=envelope;this.previews.delete(token);await this.safeCaptureReview();return this.read();
 });}
}
