import {incomeSourceName} from './income-source.js';
import {goalTarget} from './financial-goals.js';
// Shared deterministic calculations. Projections never move money.
export const round=n=>Math.round((Number(n)||0)*100)/100;
const sum=a=>round(a.reduce((n,x)=>n+Number(x||0),0));
export const shift=(d,n)=>new Date(Date.parse(d+'T12:00:00Z')+n*86400000).toISOString().slice(0,10);
const gap=(a,b)=>Math.round((Date.parse(a)-Date.parse(b))/86400000);
const median=a=>{const s=a.slice().sort((a,b)=>a-b);return s.length?(s[Math.floor((s.length-1)/2)]+s[Math.ceil((s.length-1)/2)])/2:0;};
export const perMonth=f=>({Weekly:52/12,Biweekly:26/12,Monthly:1,Quarterly:1/3,Yearly:1/12,'One-time':0}[f]||0);
export function cleanHistory(book,asOf){
 const groups=new Map(),seen=new Set(),ignored=[];
 for(const t of book.transactions||[]){if(t.excluded||t.adjustment||t.date>asOf)continue;const stable=t.externalId||t.plaidTransactionId||t.id;if(stable&&seen.has(stable)){ignored.push(t.id);continue;}seen.add(stable);const key=JSON.stringify([t.accountId,t.date,String(t.name||'').trim().toLowerCase(),t.amount,t.direction,t.historical===true]);if(!groups.has(key))groups.set(key,[]);groups.get(key).push(t);}
 const rows=[];for(const g of groups.values()){const key=g.map(t=>t.id).sort().join('|');if(g.length>1&&!(book.dismissedDuplicates||[]).includes(key)){ignored.push(...g.map(t=>t.id));continue;}rows.push(...g);}return {rows,ignored};
}
export function incomeEstimate(book,income,asOf){
 const all=cleanHistory(book,asOf),start=shift(asOf,-55),rows=all.rows.filter(t=>t.date>=start&&t.direction==='Inflow'&&!t.toAccountId&&t.category==='Income'&&(t.incomeExpectation?t.incomeExpectation.scheduleId===income.id:incomeSourceName(t.name).toLowerCase()===incomeSourceName(income.historyName||income.name).toLowerCase()));
 const amounts=rows.map(t=>t.amount),mean=amounts.length?sum(amounts)/amounts.length:0,sd=amounts.length?Math.sqrt(amounts.reduce((n,a)=>n+(a-mean)**2,0)/amounts.length):0,dates=[...new Set(rows.map(t=>t.date))].sort(),cadence=dates.length>1?median(dates.slice(1).map((d,i)=>gap(d,dates[i]))):null,cv=mean?sd/mean:0;
 const enough=rows.length>=3&&dates.length>=3;
 const wage=round((income.hourlyRate||0)*(income.hoursPerWeek||0)*(income.takeHomePercent??100)/100*(income.frequency==='Weekly'?1:income.frequency==='Biweekly'?2:income.frequency==='Monthly'?52/12:0));
 const typical=round(mean),conservative=round(Math.max(0,mean-sd)),mode=income.estimateMode||'manual';
 const amount=mode==='wages'?wage:mode==='average'&&enough?typical:mode==='conservative'&&enough?conservative:round(income.amount);
 return {id:income.id,name:income.name,mode,amount,typical,conservative,weekly:round(sum(amounts)/8),volatilityBuffer:round(sd),cadence,confidence:enough?(cv<=.15?'High':cv<=.35?'Moderate':'Low'):'Insufficient history',count:rows.length,enough,withheld:all.ignored.length,fallback:['average','conservative'].includes(mode)&&!enough,rows,variance:rows.filter(t=>t.incomeExpectation).map(t=>({date:t.date,expected:t.incomeExpectation.amount,actual:t.amount,difference:round(t.amount-t.incomeExpectation.amount)}))};
}
// Forecast policies never create deposits or modify recorded income.
export function forecastIncomeEstimate(book,income,asOf){const estimate=incomeEstimate(book,income,asOf),policy=book.settings.forecastIncome||'expected';if(policy==='manual'&&estimate.mode!=='manual')return null;if(policy==='cautious'&&estimate.mode!=='manual'){if(!estimate.enough)return null;return {...estimate,amount:Math.min(estimate.amount,estimate.conservative)};}return estimate;}
export function spendingAnalysis(book,asOf){
 const history=cleanHistory(book,asOf),rows=history.rows.filter(t=>t.direction==='Outflow'&&!t.toAccountId&&!t.paymentId&&!['Transfer','Debt payment'].includes(t.category));
 const month=asOf.slice(0,7),d=new Date(asOf+'T12:00:00Z'),prior=Array.from({length:3},(_,i)=>new Date(Date.UTC(d.getUTCFullYear(),d.getUTCMonth()-i-1,1)).toISOString().slice(0,7)),day=Number(asOf.slice(-2)),days=new Date(Date.UTC(d.getUTCFullYear(),d.getUTCMonth()+1,0)).getUTCDate();
 const categories=[...new Set(rows.map(t=>t.category||'Other'))].sort().map(category=>{const group=rows.filter(t=>(t.category||'Other')===category),past=prior.map(m=>sum(group.filter(t=>t.date.startsWith(m)).map(t=>t.amount))),current=sum(group.filter(t=>t.date.startsWith(month)).map(t=>t.amount)),avg=sum(past)/3,projected=round(current/day*days);return {category,average:round(avg),low:round(avg*.8),high:round(avg*1.2),current,projected,historyMonths:past.filter(x=>x>0).length,status:avg&&projected>avg*1.2?'High':avg?'Within range':'No baseline'};});
 const merchants=new Map();for(const t of rows.filter(t=>t.date>=shift(asOf,-180))){const name=String(t.name||'').trim().toLowerCase();if(!merchants.has(name))merchants.set(name,[]);merchants.get(name).push(t);}
 const recurring=[],leaks=[];
 for(const [name,list]of merchants){const ordered=list.slice().sort((a,b)=>a.date.localeCompare(b.date)),recent=ordered.filter(t=>t.date>=shift(asOf,-29)&&t.amount<=40);if(recent.length>=3)leaks.push({name:ordered.at(-1).name,count:recent.length,total:sum(recent.map(t=>t.amount)),ids:recent.map(t=>t.id)});
  const dates=[...new Set(ordered.map(t=>t.date))];if(dates.length<3)continue;const gaps=dates.slice(1).map((v,i)=>gap(v,dates[i])),interval=median(gaps),regular=gaps.filter(g=>Math.abs(g-interval)<=Math.max(3,interval*.2)).length/gaps.length>=.7;if(!regular||interval<5||interval>95)continue;
  const latest=ordered.at(-1),typical=median(ordered.slice(0,-1).map(t=>t.amount)),change=round(latest.amount-typical),next=shift(latest.date,Math.round(interval)),late=asOf>shift(next,Math.max(3,Math.round(interval*.25)));recurring.push({name:latest.name,interval:Math.round(interval),latest:latest.amount,typical:round(typical),change,last:latest.date,next,signal:late?'May have stopped':change>Math.max(1,typical*.05)?'Price increase':dates.length===3?'New recurring pattern':'Stable',ids:ordered.map(t=>t.id)});
 }
 const heatmap={};for(const t of rows.filter(t=>t.date.startsWith(asOf.slice(0,4)))){const k=t.category||'Other';heatmap[k]??=Array(12).fill(0);heatmap[k][Number(t.date.slice(5,7))-1]=round(heatmap[k][Number(t.date.slice(5,7))-1]+t.amount);}
 return {categories,recurring,leaks:leaks.sort((a,b)=>b.total-a.total),heatmap,withheld:history.ignored.length,rows};
}
export function debtSimulation(accounts,extraWeekly=0,strategy='avalanche',priorityId=''){
 const debts=accounts.filter(a=>a.kind!=='cash'&&a.balance>0).map(a=>({...a,left:a.balance,monthly:(a.payment||0)*perMonth(a.frequency)}));const regular=sum(debts.map(a=>a.monthly)),budget=round(regular+Math.max(0,extraWeekly)*52/12),schedule=[];let interest=0;
 if(!debts.length)return {months:0,interest:0,total:0,paidOff:[],schedule:[],limited:false};
 for(let month=1;month<=600;month++){let available=budget;for(const a of debts.filter(a=>a.left>0)){const charge=round(a.left*(a.apr||0)/1200);interest+=charge;a.left+=charge;const paid=Math.min(a.left,a.monthly,available);a.left=round(a.left-paid);available=round(available-paid);if(a.left<=.005&&!a.paidMonth)a.paidMonth=month;}
  const ordered=debts.filter(a=>a.left>0).sort((a,b)=>a.id===priorityId?-1:b.id===priorityId?1:strategy==='snowball'?a.left-b.left:(b.apr||0)-(a.apr||0)||a.left-b.left);
  for(const a of ordered){const paid=Math.min(a.left,available);a.left=round(a.left-paid);available=round(available-paid);if(a.left<=.005&&!a.paidMonth)a.paidMonth=month;}
  schedule.push({month,balance:sum(debts.map(a=>a.left))});if(schedule.at(-1).balance<=.005)return {months:month,interest:round(interest),total:budget,paidOff:debts.map(a=>({id:a.id,name:a.name,month:a.paidMonth})),schedule,limited:false};
 }return {months:null,interest:round(interest),total:budget,paidOff:debts.filter(a=>a.paidMonth).map(a=>({id:a.id,name:a.name,month:a.paidMonth})),schedule,limited:true};
}
export function wishesPausedForBuffer(data){return data?.pauseWishesBelowBuffer!==false&&Number.isFinite(data?.cash?.balance)&&data.cash.balance<data.cash.bufferTarget;}
export function allocatePaycheck(book,data){
 const next=data.nextPaychecks.map(x=>x.date).sort()[0];if(!next)return null;const after=data.nextPaychecks.map(x=>x.date).filter(d=>d>next).sort()[0],points=data.plan.forecast.filter(p=>p.date>=next&&(!after||p.date<after)),amount=sum(data.nextPaychecks.filter(p=>p.date===next).map(p=>p.amount)),required=sum(data.upcoming.filter(e=>e.date>=next&&(!after||e.date<after)).map(e=>e.amount));
 const headroom=points.length?Math.max(0,Math.min(...points.map(p=>p.cash))-data.cash.bufferTarget):0,surplus=data.ready&&!data.plan.forecast.some(p=>p.date<next&&p.cash<data.cash.bufferTarget)?Math.max(0,Math.min(amount-required,headroom)):0,buffer=round(Math.max(0,amount-required-surplus)),weights=book.settings.allocations||{debt:35,sinking:15,goals:10,wishes:25,flex:15},parts={};let used=0;const keys=['debt','sinking','goals','wishes','flex'];for(const k of keys){parts[k]=round(surplus*weights[k]/100);used+=parts[k];}parts.flex=round(parts.flex+surplus-used);
 // Empty/completed/paused destinations cannot receive a suggested allocation.
 const eligible=(g,list)=>g.active!==false&&!(list==='goals'&&g.goalType==='debt')&&Number(g.saved||0)<Number(list==='goals'?goalTarget(g,book):g.cost||0)&&effectiveSavingsStyle(g,data.asOf)!=='Pause'&&!(list==='wishes'&&wishPauseState(g,book,data.asOf).manualPaused);
 const available={debt:data.accounts.some(a=>a.active!==false&&a.kind!=='cash'&&a.balance>0),goals:(book.goals||[]).some(g=>eligible(g,'goals')),sinking:(book.sinking||[]).some(g=>eligible(g,'sinking')),wishes:(book.wishes||[]).some(g=>eligible(g,'wishes'))};
 for(const k of ['debt','goals','sinking','wishes'])if(!available[k]){parts.flex=round(parts.flex+parts[k]);parts[k]=0;}
 const wishBufferHold=wishesPausedForBuffer(data)?parts.wishes:0;if(wishBufferHold)parts.wishes=0;
 return {date:next,until:points.at(-1)?.date||next,truncated:!after,amount,required,buffer:round(buffer+wishBufferHold),surplus:round(surplus-wishBufferHold),parts,weights,wishBufferHold,shortfall:Math.max(0,round(required-amount))};
}
export function effectiveSavingsStyle(g,asOf){
 if(g.style==='Pause'&&g.pauseUntil&&g.pauseUntil<=asOf)return g.resumeStyle==='Custom'?'Custom':'Automatic';
 return g.style||'Automatic';
}
export function wishPauseState(w,book,asOf,data){
 const manual=effectiveSavingsStyle(w,asOf)==='Pause',dates=(book.cooling||[]).filter(c=>c.date>asOf&&(c.wishId===w.id||!c.wishId&&c.name===w.name)).map(c=>c.date),bufferPaused=wishesPausedForBuffer(data);
 if(manual&&!w.pauseUntil)return {paused:true,manualPaused:true,bufferPaused,until:''};
 if(manual)dates.push(w.pauseUntil);
 return {paused:bufferPaused||dates.length>0,manualPaused:dates.length>0,bufferPaused,until:dates.sort().at(-1)||''};
}
export function savingsPlans(book,data){
 const budget=allocatePaycheck(book,data),weeks=budget?Math.max(1,(gap(budget.until,budget.date)+1)/7):1,groups={wishes:book.wishes.map(w=>wishPauseState(w,book,data.asOf,data).paused?{...w,style:'Pause',pauseUntil:''}:w),goals:book.goals.filter(g=>g.goalType!=='debt').map(g=>({...g,cost:goalTarget(g,book)})),sinking:book.sinking},out=[];
 for(const [list,targets]of Object.entries(groups)){const pool=budget?round(budget.parts[list]/weeks):0,custom=sum(targets.filter(g=>effectiveSavingsStyle(g,data.asOf)==='Custom').map(g=>g.weekly)),autos=targets.filter(g=>effectiveSavingsStyle(g,data.asOf)==='Automatic'&&g.saved<g.cost).sort((a,b)=>Number(!!b.focus)-Number(!!a.focus)||({High:0,Normal:1,Low:2}[a.priority||'Normal']-({High:0,Normal:1,Low:2}[b.priority||'Normal']))),available=Math.max(0,pool-custom),weight=g=>g.priority==='High'?3:g.priority==='Low'?1:2,total=autos.reduce((n,g)=>n+weight(g),0),focus=autos.find(g=>g.focus);
  for(const g of targets){const rawWeekly=effectiveSavingsStyle(g,data.asOf)==='Pause'||g.saved>=g.cost?0:effectiveSavingsStyle(g,data.asOf)==='Custom'?g.weekly:focus?(g.id===focus.id?available:0):available*weight(g)/(total||1),weekly=round(rawWeekly),remaining=Math.max(0,g.cost-g.saved),weeksNeeded=weekly>0?Math.ceil(remaining/weekly):Infinity,ready=remaining<=0?data.asOf:weeksNeeded<=5200?shift(data.asOf,weeksNeeded*7):null;out.push({id:g.id,list,name:g.name,weekly:round(weekly),ready,remaining:round(remaining),overallocated:custom>pool,pool,focus:!!g.focus});}
 }return out;
}
export function activityTotals(book,data,start,end){
 const history=cleanHistory(book,data.asOf),rows=history.rows.filter(t=>t.date>=start&&t.date<=end),income=sum(rows.filter(t=>t.direction==='Inflow'&&!t.toAccountId&&t.category==='Income').map(t=>t.amount)),spending=sum(rows.filter(t=>t.direction==='Outflow'&&!t.toAccountId&&!t.paymentId&&!['Transfer','Debt payment'].includes(t.category)).map(t=>t.amount)),payments=sum(book.payments.filter(p=>p.date>=start&&p.date<=end&&p.date<=data.asOf).map(p=>p.amount)),unlinkedDebt=sum(rows.filter(t=>t.direction==='Outflow'&&!t.paymentId&&t.category==='Debt payment').map(t=>t.amount));
 const cashIds=new Set(book.accounts.filter(a=>a.kind==='cash').map(a=>a.id)),cashFlow=sum(rows.filter(t=>cashIds.has(t.accountId)&&!t.toAccountId&&t.category!=='Transfer').map(t=>t.direction==='Inflow'?t.amount:-t.amount)),directCashPayments=sum(book.payments.filter(p=>p.date>=start&&p.date<=end&&p.date<=data.asOf&&cashIds.has(p.fundingId)&&!p.transactionId).map(p=>p.amount));
 return {income,spending,payments:round(payments+unlinkedDebt),net:round(cashFlow-directCashPayments),withheld:history.ignored.length,recordCount:rows.length};
}
export function monthlyReport(book,data,month){return {month,...activityTotals(book,data,month+'-01',month+'-31')};}
export function analyzeBudget(book,data){const income=book.incomes.filter(i=>i.active!==false).map(i=>incomeEstimate(book,i,data.asOf)),spending=spendingAnalysis(book,data.asOf),allocation=allocatePaycheck(book,data),savings=savingsPlans(book,data),baseline=debtSimulation(data.accounts,0,book.settings.debtStrategy||'avalanche',book.settings.priorityDebt||''),issues=[];
 for(const c of spending.categories.filter(c=>c.status==='High'))issues.push({id:'pace:'+c.category+':'+data.asOf.slice(0,7),title:c.category+' is above its usual pace',detail:`Projected ${c.projected}; usual upper range ${c.high}.`,action:'transactions'});
 for(const m of spending.recurring.filter(m=>m.signal!=='Stable'))issues.push({id:'merchant:'+m.name+':'+m.last,title:m.name+': '+m.signal,detail:`Latest ${m.latest}, typical ${m.typical}. Expected around ${m.next}. Pattern only; confirm before changing a bill.`,action:'calendar'});
 for(const m of spending.leaks.slice(0,3))issues.push({id:'leak:'+m.name+':'+data.asOf.slice(0,7),title:'Small purchases at '+m.name,detail:`${m.count} purchases of 40 or less total ${m.total} over 30 days.`,action:'transactions'});
 if(data.ready&&data.cash.minimumCash<data.cash.bufferTarget)issues.push({id:'buffer:'+data.cash.minimumCashDate,title:'Protect your buffer',detail:`Lowest projected cash ${data.cash.minimumCash} on ${data.cash.minimumCashDate}.`,action:'plan'});
 if(allocation?.parts.debt>0)issues.push({id:'extra-debt:'+allocation.date,title:'Room for an extra debt payment',detail:`Your next paycheck plan assigns ${allocation.parts.debt} to extra debt. Preview before paying.`,action:'debt'});
 const incomeConf=income.length?income.reduce((n,i)=>n+(i.confidence==='High'?100:i.confidence==='Moderate'?65:i.confidence==='Low'?30:0),0)/income.length:0,confidence=Math.round((data.ready?50:0)+incomeConf*.3+(spending.withheld?0:10)+(book.reviewTransactions.length?0:10));
 const accountIds=new Set(book.accounts.map(a=>a.id)),diagnostics=[];for(const t of book.transactions)if(!accountIds.has(t.accountId)||t.toAccountId&&!accountIds.has(t.toAccountId))diagnostics.push('Transaction '+t.name+' references a missing account.');for(const p of book.payments){if(!accountIds.has(p.debtId)||p.fundingId&&!accountIds.has(p.fundingId))diagnostics.push('Payment '+(p.debtName||p.id)+' references a missing account.');if(p.transactionId&&!book.transactions.some(t=>t.id===p.transactionId&&t.paymentId===p.id))diagnostics.push('Payment '+(p.debtName||p.id)+' has a broken transaction link.');}if(data.protectedSavings>data.cash.balance)diagnostics.push('Reserved savings exceed your cash balance. Review targets and accounts.');for(const a of data.accounts)if(gap(data.asOf,a.confirmedAt||a.balanceDate)>14)diagnostics.push(a.name+' has not been confirmed in more than 14 days.');
 return {income,spending,allocation,savings,baseline,confidence,diagnostics,issues:issues.filter(i=>{const state=book.insightStates?.[i.id];return !state||state.status==='snoozed'&&state.until<=data.asOf;}),reports:[...new Set([data.asOf.slice(0,7),...spending.rows.map(t=>t.date.slice(0,7)),...book.transactions.filter(t=>t.category==='Income').map(t=>t.date.slice(0,7))])].sort().reverse().map(m=>monthlyReport(book,data,m))};}

// Suggestions are evidence only: never create payments or move bank balances.
export const recurringMerchant=name=>String(name||'').normalize('NFKC').trim().toLowerCase().replace(/[^\p{L}\p{N}]+/gu,' ').trim();
export function recurringBillSuggestions(book,asOf,{allowIncomeGaps=false}={}){
 const groups=new Map(),accounts=new Map((book.accounts||[]).map(a=>[a.id,a]));
 for(const t of cleanHistory(book,asOf).rows){
  if(t.pending||t.direction!=='Outflow'||t.toAccountId||t.paymentId||!(t.amount>0)||!/^\d{4}-\d{2}-\d{2}$/.test(t.date)||!Number.isFinite(Date.parse(t.date))||['transfer','debt payment','debt','income'].includes(String(t.category).toLowerCase())||!accounts.has(t.accountId)||accounts.get(t.accountId).kind==='loan')continue;
  const merchant=recurringMerchant(t.merchantName||t.name);if(!merchant)continue;
  const key=JSON.stringify([t.accountId,merchant]);if(!groups.has(key))groups.set(key,[]);groups.get(key).push(t);
 }
 const results=[];
 for(const [key,all]of groups){
  const ordered=all.sort((a,b)=>a.date.localeCompare(b.date)).slice(-8),dates=ordered.map(t=>t.date);
  // Multiple same-day charges may be separate purchases or unmatched duplicates.
  if(ordered.length<3||new Set(dates).size!==dates.length)continue;
  const gaps=dates.slice(1).map((d,i)=>gap(d,dates[i])),interval=median(gaps),last=ordered.at(-1),merchant=recurringMerchant(last.merchantName||last.name);
  let frequency,step,cadenceNeedsReview=false;
  for(const [f,n,tolerance]of [['Weekly',7,2],['Biweekly',14,3],['Monthly',30.44,4],['Quarterly',91.31,7],['Yearly',365.25,10]])if(Math.abs(interval-n)<=tolerance&&gaps.every(g=>Math.abs(g-n)<=tolerance)){frequency=f;step=n;break;}
  // Income may skip a pay period. Require a directly observed base interval,
  // and allow at most one missing period per gap; never invent deposits.
  if(!frequency&&allowIncomeGaps){
   for(const [f,n,tolerance] of [['Weekly',7,2],['Biweekly',14,3]]){
    if(gaps.some(g=>Math.abs(g-n)<=tolerance)&&gaps.every(g=>Math.abs(g-n)<=tolerance||Math.abs(g-2*n)<=tolerance)){
     frequency=f;step=n;cadenceNeedsReview=true;break;
    }
   }
  }
  if(!frequency)continue;
  let next;
  if(step<20)next=shift(last.date,Math.round(step));else{
   const d=new Date(last.date+'T12:00:00Z'),months={Monthly:1,Quarterly:3,Yearly:12}[frequency],month=d.getUTCMonth()+months,year=d.getUTCFullYear();
   const monthEnd=dates.every(s=>{const v=new Date(s+'T12:00:00Z');return v.getUTCDate()===new Date(Date.UTC(v.getUTCFullYear(),v.getUTCMonth()+1,0)).getUTCDate();});
   const day=monthEnd?31:Math.max(...dates.map(s=>Number(s.slice(-2))));
   next=new Date(Date.UTC(year,month,Math.min(day,new Date(Date.UTC(year,month+1,0)).getUTCDate()))).toISOString().slice(0,10);
  }
  // Do not guess that a long-stopped subscription still exists.
  if(gap(asOf,next)>Math.max(3,Math.round(step*.2)))continue;
  const existing=(book.bills||[]).some(b=>b.active!==false&&b.frequency!=='One-time'&&(b.recurringSource===key||recurringMerchant(b.name)===merchant));
  const debt=(book.accounts||[]).some(a=>a.kind!=='cash'&&a.payment>0&&recurringMerchant(a.name)===merchant);
  if(existing||debt)continue;
  const low=Math.min(...ordered.map(t=>t.amount)),high=Math.max(...ordered.map(t=>t.amount));
  results.push({key,name:last.merchantName||last.name,accountId:last.accountId,accountName:accounts.get(last.accountId).name,frequency,cadenceNeedsReview,amount:last.amount,category:last.category,next:next<asOf?asOf:next,expected:next,low,high,variable:high-low>Math.max(1,median(ordered.map(t=>t.amount))*.05),evidence:ordered.map(t=>({id:t.id,date:t.date,amount:t.amount})),dismissed:(book.dismissedRecurring||[]).includes(key)});
 }
 return results.sort((a,b)=>a.next.localeCompare(b.next)||a.name.localeCompare(b.name));
}

// Income suggestions reuse cadence checks, with a separate deposit-only evidence set.
export function recurringIncomeSuggestions(book,asOf){
 const cash=new Set((book.accounts||[]).filter(a=>a.kind==='cash'&&a.active!==false).map(a=>a.id));
 const transactions=(book.transactions||[]).filter(t=>t.direction==='Inflow'&&cash.has(t.accountId)&&!t.toAccountId&&!t.paymentId&&!t.adjustment&&!t.excluded&&!t.pending&&t.category==='Income'&&!/\b(refund|reversal|transfer|cashback|cash back|reimbursement)\b/i.test(t.name||''));
 const projected={...book,accounts:(book.accounts||[]).filter(a=>cash.has(a.id)),transactions:transactions.map(t=>({...t,name:incomeSourceName(t.name),merchantName:incomeSourceName(t.name),direction:'Outflow',category:'Other'})),bills:(book.incomes||[]).map(i=>({...i,name:incomeSourceName(i.historyName||i.name),frequency:'Monthly',recurringSource:i.recurringSource})),dismissedRecurring:book.dismissedIncomeSuggestions||[]};
 return recurringBillSuggestions(projected,asOf,{allowIncomeGaps:true}).map(s=>({...s,amount:round(median(s.evidence.map(t=>t.amount))),latest:s.amount}));
}

// Goal projections reserve each contribution through the rest of the forecast.
// Earlier shortfalls do not prevent saving after a later paycheck restores cash.
export function projectGoalSavings(book,data){
 const points=data.plan.forecast.slice(0,60),dates=[...new Set(data.nextPaychecks.map(p=>p.date))].filter(d=>points.some(p=>p.date===d)).sort();
 const goals=(book.goals||[]).filter(g=>g.active!==false&&g.goalType!=='debt');
 const alreadySaved=sum(goals.map(g=>g.saved)),funded=new Map(goals.map(g=>[g.id,Number(g.saved)||0])),completed=new Map();let reserved=0;
 const rows=dates.map(date=>{
  const eligible=goals.filter(g=>effectiveSavingsStyle(g,date)!=='Pause'&&funded.get(g.id)<goalTarget(g,book));
  const remaining=sum(eligible.map(g=>goalTarget(g,book)-funded.get(g.id)));
  const tail=points.filter(p=>p.date>=date).map(p=>({...p,cash:round(p.cash-reserved)}));
  const amount=sum(data.nextPaychecks.filter(p=>p.date===date).map(p=>p.amount));
  const headroom=Math.max(0,round(Math.min(...tail.map(p=>p.cash))-data.cash.bufferTarget));
  // A forecast contribution uses available cash, not the optional allocation weights.
  const contribution=data.ready&&remaining>0?round(Math.min(remaining,amount,headroom)):0;
  // Allocate to outstanding targets in priority order; this prevents completed
  // targets from receiving the same forecasted savings on every paycheck.
  let left=contribution;
  for(const g of eligible.slice().sort((a,b)=>({High:0,Normal:1,Low:2}[a.priority||'Normal']??1)-({High:0,Normal:1,Low:2}[b.priority||'Normal']??1))){const n=Math.min(left,goalTarget(g,book)-funded.get(g.id));funded.set(g.id,round(funded.get(g.id)+n));if(funded.get(g.id)>=goalTarget(g,book)&&!completed.has(g.id))completed.set(g.id,date);left=round(left-n);}
  reserved=round(reserved+contribution);
  return {date,amount,contribution,projectedSaved:round(alreadySaved+reserved),lowestAfter:round(Math.min(...tail.map(p=>p.cash))-contribution),reason:!data.ready?'Confirm planning setup':!remaining?'No active unfunded goals':!headroom?'Protecting your buffer':contribution?'Above buffer through forecast': 'No paycheck surplus available'};
 });
 return {alreadySaved,projectedContributions:reserved,projectedSaved:round(alreadySaved+reserved),rows,end:points.at(-1)?.date||data.asOf,goals:goals.map(g=>({id:g.id,list:'goals',projected:round(funded.get(g.id)-(Number(g.saved)||0)),projectedSaved:funded.get(g.id),ready:completed.get(g.id)||null,forecastEnd:points.at(-1)?.date||data.asOf}))};
}
